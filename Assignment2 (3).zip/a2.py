# a2.py

# Starter code for assignment 2 in ICS 32 Programming with Software Libraries in Python

# Replace the following placeholders with your information.

# Tulasi Janjanam
# hjanjana@uci.edu
# 35885208


from pathlib import Path
from Profile import Profile
from Profile import Post
from ui import UI
import json

global call_profile

def list_directory(path, recursive=False, files_only=False, search_name=None, extension=None):
    directory = Path(path)
    if not directory.exists() or not directory.is_dir():
        print("ERROR")
        return

    def condition(p):
        if files_only and p.is_dir():
            return False
        if search_name and search_name not in p.name:
            return False
        if extension and not p.suffix == f".{extension}":
            return False
        return True

    def list_contents(dir_path):
        try:
            for entry in dir_path.iterdir():
                if condition(entry):
                    print(entry)
                if recursive and entry.is_dir():
                    list_contents(entry)
        except PermissionError:
            print("ERROR")

    list_contents(directory)


def create_file(path, name):
    file_path = Path(path) / f"{name}.dsu"
    try:
        # file_path.touch()
        username = ui.get_username()
        password = ui.get_password()
        bio = ui.get_bio()
        
    
                
        x = {"username": username, 
             "password": password,
             "dsuserver": None,
             "bio": bio, 
             "_posts": []
            }
                
        y = json.dumps(x)
        
        if username and password and bio:
            with open(file_path, "w") as file:
                file.write(y)
        
        
        global call_profile
        call_profile = Profile(None, username, password)
       
                
    except Exception as e:
        print("ERROR:", e)
        
def delete_file(path):
    file_path = Path(path)
    if file_path.suffix != '.dsu' or not file_path.is_file():
        print("ERROR")
        return
    try:
        file_path.unlink()
        print(f"{file_path} DELETED")
    except Exception as e:
        print("ERROR:", e)
        
def read_file(path):
    file_path = Path(path)
    if file_path.suffix != '.dsu' or not file_path.is_file():
        print("ERROR")
        return
    try:
        content = file_path.read_text()
        if not content:
            print("EMPTY")
        else:
            print(content,end='')
    except Exception as e:
        print("ERROR:", e)
        
def open_file(path):
    file_path = Path(path)
    
    if file_path.suffix == '.dsu':
        try:
            with open(file_path, "r") as file:
                print(f"{file_path} Sucessfuly opened.")
                profile = Profile()
                profile.load_profile(file_path)


                return file_path
                # print(f'user: {profile.username}')
                return
        except FileNotFoundError as e:
            print("There is no file with this name. Please try again.")
            return ""
    else:
        print("Sorry, invalid file format. Please only enter a file ending in .dsu")
        return ""



def edit_file(path: Path , commandList):
    file_path = Path(path)
    
    user = ""
    pwd = ""
    bio = ""
    addpost = ""
    delPost = -1
    
    i = 0
    for command in commandList[::2]:
        if command == "-usr":
            user = commandList[i+1]
            
        elif command == "-pwd":
            pwd = commandList[i+1]
            
        elif command == "-bio":
            bio = commandList[i+1]
            
        elif command == "-addpost":
            addpost = commandList[i+1]
            
        elif command == "-delpost":
            delPost = int(commandList[i+1]) - 1
            
        else:
            print("ERROR")
            
        i += 2


        with open(file_path, "r") as file:
                content = file.read()


        a = json.loads(content)


        if user:
            a['username'] = user

        if pwd:
            a['password'] = pwd

        if bio:
            a['bio'] = bio

        if addpost:
            a['_posts'].append(Post(addpost,0))

        if delPost >= 0:
            if len(a['_posts']) > delPost:
                a['_posts'].pop(delPost)
                print("Post deleted.")
            else:
                print("That post does not exist.")


        with open(file_path, "w") as file:
             file.write(json.dumps(a))
                

def print_file(path: Path , commandList):
    file_path = Path(path)



    try:    
        with open(file_path, "r") as file:
                content = file.read()
    except FileNotFoundError as e:
        print("File not found")
        return

    a = json.loads(content)
    
    i = 0
    while i < len(commandList):
        command = commandList[i]
        
        if command == "-usr":
            print(a["username"])
            
        elif command == "-pwd":
            print(a["password"])
            
        elif command == "-bio":
            print(a["bio"])
            
        elif command == "-posts":
            for post in a["_posts"]:
                print(post["entry"])
            
        elif command == "-all":
            for entry in a:
                if(a[entry]):
                    if entry == "_posts":
                        for post_object in a[entry]:
                            print(post_object["entry"])
                    else:
                        print(a[entry])
            
        elif command == "-post":
            i += 1
            index = int(commandList[i]) - 1
            
            if(index < len(a["_posts"])):
                print(a["_posts"][index]["entry"])
            else:
                print("That post does not exist")
            
        i += 1

            
            
def admin_mode():

    path = ""
    call_profile = Profile()
    
    while True:
        user_input = ui.get_admin_user_input()
        
        isinquotes = False
        input_list = []
        tempString = ""
        
        
        for i in user_input:
            if i == '"' or i == "'":
                isinquotes = not isinquotes
               
                
            if not isinquotes and i == " ":
                input_list.append(tempString)
                tempString = ""
   
                    
            else:
                if i != '"':
                    tempString += i
                    
        input_list.append(tempString)
            
        user_input = input_list

        
        if not user_input:
            continue

        command = user_input[0].upper()
           
        
        if command == 'E' and path:
            edit_file(path, user_input[1:])
        elif command == 'P' and path:
            print_file(path, user_input[1:])  
        else:   
            path = user_input[1] if len(user_input) > 1 else None
            
        

        if command == 'Q':
            break
        elif command == 'L':
            path = user_input[1] if len(user_input) > 1 else "."
            recursive = '-r' in user_input
            files_only = '-f' in user_input
            search_option = '-s' in user_input
            extension_option = '-e' in user_input
            search_name = None
            extension = None

            if search_option:
                search_name_index = user_input.index('-s') + 1
                if search_name_index < len(user_input):
                    search_name = user_input[search_name_index]

            if extension_option:
                extension_index = user_input.index('-e') + 1
                if extension_index < len(user_input):
                    extension = user_input[extension_index]

            list_directory(path, recursive, files_only, search_name, extension)

        elif command == 'C' and path:
            name_index = user_input.index('-n') + 1 if '-n' in user_input else None
            name = user_input[name_index] if name_index and name_index < len(user_input) else None
            if name:
                create_file(path, name)
                
                path = path + name + ".dsu"
                
            else:
                print("ERROR")

        elif command == 'D' and path:
            delete_file(path)

        elif command == 'R' and path:
            read_file(path)
            
        elif command == 'O' and path:
            open_file(path)
        elif command == "E":
            pass
        elif command == "P":
            pass
        else:
            print("ERROR")



def user_mode():
    path = ""
    call_profile = Profile()
    
    while True:
        if path == "":
            user_input = ui.get_user_input()
        else:
            user_input = ui.get_user_input_with_path(path)

        user_input = splitCommands(user_input)


        
        if not user_input:
            continue

        command = user_input[0].upper()

           
        if command == 'E' and path:
            user_input = splitCommands(ui.get_user_edit_commands())

            if len(user_input) > 1:
                edit_file(path, user_input)
            else:
                print("No value was entered, please try again")
        elif command == 'P' and path:
            user_input = splitCommands(ui.get_user_print_commands())
     
            print_file(path, user_input)
        elif command == 'P' or command == 'E':
            print("Sorry, could not find a file. Please open or create a file first.")
#            path = user_input[1] if len(user_input) > 1 else None
            
        

        if command == 'Q':
            print("Exiting the program. Have a nice day!")
            return "Q"
        elif command == "ADMIN":
            return "ADMIN"
        elif command == 'L':
            temp_path = input("What folder would you like to list out?\n")
            
            print("Here is a list of all of the files under this folder")
            recursive = '-r' in user_input
            files_only = '-f' in user_input
            search_option = '-s' in user_input
            extension_option = '-e' in user_input
            search_name = None
            extension = None

            if search_option:
                search_name_index = user_input.index('-s') + 1
                if search_name_index < len(user_input):
                    search_name = user_input[search_name_index]

            if extension_option:
                extension_index = user_input.index('-e') + 1
                if extension_index < len(user_input):
                    extension = user_input[extension_index]

            list_directory(temp_path, recursive, files_only, search_name, extension)


        elif command == 'C':
            path = ui.get_file_location()
            name = ui.get_file_name()

            
            if name and path:
                create_file(path, name)

                print("File Created.")
                
                path = path + name + ".dsu"
                
            else:
                print("Sorry, there was an error in your input, please try again.")
                path = ""
                

        elif command == 'D':
            temp_path = ui.get_name_and_location()
            
            delete_file(temp_path)
            
        elif command == 'R':
            path = ui.get_name_and_location()
            
            read_file(path)
            
        elif command == 'O':
            temp_path = ui.get_name_and_location()
            
            path = open_file(temp_path)
            
        elif command == "E":
            pass
        elif command == "P":
            pass
        else:
            print("Sorry, there was an error in your input, please try again.")




        
def splitCommands(user_input):
          
        isinquotes = False
        input_list = []
        tempString = ""
        
        
        for i in user_input:
            if i == '"' or i == "'":
                isinquotes = not isinquotes
               
                
            if not isinquotes and i == " ":
                input_list.append(tempString)
                tempString = ""
   
                    
            else:
                if i != '"':
                    tempString += i
        input_list.append(tempString)
            
        return input_list
    

def main():
    adminMode = False
    global ui
    ui = UI()
    
    #firstInput = input("Welcome! Do you want to create or load a DSU file (type 'c' to create or 'l' to load):")
    
  #  if(firstInput.upper()) == "ADMIN":
  #      adminMode = True

    while True:
        if(adminMode):
            admin_mode()
            return
        else:
            command = user_mode()

            if(command == "Q"):
                return
            elif(command == "ADMIN"):
                adminMode = True
                print("Entering admin mode.")
    


if __name__ == "__main__":
    main()