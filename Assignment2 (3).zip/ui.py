# ui.py

# Starter code for assignment 2 in ICS 32 Programming with Software Libraries in Python

# Replace the following placeholders with your information.

# Tulasi Janjanam
# hjanjana@uci.edu
# 35885208

class UI():
    def get_username(self):
        return input("What is your username?\n")

    def get_password(self):
        return input("What is your password?\n")

    def get_bio(self):
        return input("What is a brief description?\n")

    def get_admin_user_input(self):
        return input()

    def get_user_input(self):
        return input("\nType 'L' to list all files, 'C' to create a new file, 'O' to open a file, or 'D' to delete a file.\n")

    def get_user_input_with_path(self, path):
        return input("""\nType 'L' to list all files, 'C' to create a new file, 'O' to open a file, or 'D' to delete a file.
You can also type 'E' to edit the current file, or 'P' to print the current file.
Current opened file: """ + str(path) + "\n")

    def get_user_edit_commands(self):
        return input("""Please type the field you would like to edit, followed by the new value.
Username: '-usr'
Password: '-pwd'
Bio: '-bio'
Add a Post: '-addpost'
Delete a Post: '-delpost' + post ID
""")

    def get_user_print_commands(self):
        return input("""Please type the field you would like to print.
Username: '-usr'
Password: '-pwd'
Bio: '-bio'
All Posts: '-posts'
Single Post: '-post' + post ID
Everything: '-all'
""")

    def get_file_location(self):
        return input("Where would you like to create this file?\n")

    def get_file_name(self):
        return input("And what do you want to name this file?\n")

    def get_name_and_location(self):
        return input("What is the directory and name of the file?\n")