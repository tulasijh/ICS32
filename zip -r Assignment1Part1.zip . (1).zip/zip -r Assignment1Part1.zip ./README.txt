Name: Tulasi Janjanam
Email: hjanjana@uci.edu

File Management Tool

This is a simple command-line tool for inspecting the contents of a folder. The tool supports two main commands:

L: List the contents of a user-specified directory.
Q: Quit the program.
The 'L' command can be extended with various options:

-r: Output directory content recursively.
-f: Output only files, excluding directories.
-s: Output only files that match a given file name.
-e: Output only files that match a given file extension.
