import os

def list_directory(place, options):
    # Get the contents of the specified directory and sort them
    contents = sorted(os.listdir(place))

    for content in contents:
        full_path = os.path.join(place, content)

        # If the '-r' option is provided and the current content is a directory, recursively list its contents
        if options and options[0] == '-r' and os.path.isdir(full_path):
            list_directory(full_path, options)
        # If no options are provided or options match the specified criteria, print the full path
        elif not options or (options[0]):
            print(full_path)

def main():
    while True:
        # Get user input and split it into a list
        user_input = input("Enter command: ").split()
        command = user_input[0].upper()

        # Check the command and take appropriate actions
        if command == 'Q':
            print("Exiting program.")
            break
        elif command == 'L':
            # Get the directory path and options from user input
            directory_path = user_input[1] if len(user_input) > 1 else '.'
            options = user_input[2:]
            list_directory(directory_path, options)
        else:
            print("Invalid command. Try again.")

if __name__ == "__main__":
    main()
