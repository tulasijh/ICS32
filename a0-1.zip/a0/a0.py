# a0.py

# Starter code for assignment 0 in ICS 32 Programming with Software Libraries in Python

# Replace the following placeholders with your information.

# Tulasi Janjanam
# hjanjana@uci.edu
# 35885208


value = input("Number of times to repeat: ")
num = int(value)
for i in range(0, num):
    print('+-+')
    print(" " * 2 * i + '| |')
    if (i != num - 1):
        print(" " * 2 * i + '+-', end="")
    else:
        print(" " * 2 * i + '+-+')
