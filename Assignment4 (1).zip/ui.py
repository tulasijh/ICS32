# Tulasi Janjanam
# hjanjana@uci.edu
# 35885208

# ui.py



# Replace the following placeholders with your information.



class UI():
    def get_username(self):
        return input("What is your username?\n")

    def get_password(self):
        return input("What is your password?\n")

    def get_bio(self):
        return input("What is a brief description?\n")

    def get_admin_user_input(self):
        return input()

    def get_user_input(self):
        return input("\nType 'Q' to quit, 'L' to list all files, 'C' to create a new file, 'O' to open a file, or 'D' to delete a file.\n")

    def get_user_input_with_path(self, path):
        return input("""\nType 'Q' to quit, 'L' to list all files, 'C' to create a new file, 'O' to open a file, or 'D' to delete a file.
You can also type 'E' to edit the current file, or 'P' to print the current file.
Current opened file: """ + str(path) + "\n")

    def get_user_edit_commands(self):
        return input("""Please type the field you would like to edit, followed by the new value.
Username: '-usr'
Password: '-pwd'
DSP Server IP: '-ip'
Bio: '-bio'
Add a Post: '-addpost' (Pro Tip: use @weather for current weather, @lastfm for the top three artists, or @topArtist to get the top Artist!)
Delete a Post: '-delpost' + post ID
""")

    def get_user_print_commands(self):
        return input("""Please type the field you would like to print.
Username: '-usr'
Password: '-pwd'
Bio: '-bio'
All Posts: '-posts'
Single Post: '-post' + post ID
Everything: '-all'
""")

    def get_file_location(self):
        return input("Where would you like to create this file?\n")

    def get_file_name(self):
        return input("And what do you want to name this file?\n")

    def get_name_and_location(self):
        return input("What is the directory and name of the file?\n")

    def get_dsp_server(self):
        return input("What is your desired DSP server ip?\n")
    
    def get_publish_permission(self):
        return input("\nWould you like to post this post (y/n)?\n")
    
    def get_multi_publish_permission(self):
        return input("\nWould you like to post these posts (y/n)?\n")

    def get_bio_publish_permission(self):
        return input("\nWould you like to post this bio? (y/n)?\n")

    def get_zip_code(self):
        return input("\nPlease enter your zipcode\n")
    
    def get_ccode(self):
        return input("\nPlease enter your country code (i.e. \"US\")\n")
    
    def get_lastfm_key(self):
        return input("\nPlease enter your lastFM API key\n")
    
    def get_weather_key(self):
        return input("\nPlease enter your OpenWeather API key\n")