# LastFM.py
# Tulasi Janjanam
# hjanjana@uci.edu
# 35885208


from WebAPI import WebAPI

# lastfm_apikey = "55ea4a5308a451afbe7dce83b5b4c1ce"

class LastFM(WebAPI):
    apikey = ""

    baseurl = "http://ws.audioscrobbler.com/2.0/"

    data = None

    # def __init__(self, zipcode: str, ccode: str):
    #     self.zip = zipcode
    #     self.ccode = ccode

    def set_apikey(self, apikey: str) -> None:
        self.apikey = apikey

    def load_data(self) -> None:
        url = f"http://ws.audioscrobbler.com/2.0/?method=chart.gettopartists&api_key={self.apikey}&format=json"
    
        r = super()._download_url(url)

        self.artistList = []

        for artist in r["artists"]["artist"]:
            self.artistList.append({"name":artist["name"], "playcount": artist["playcount"]})

        self.artistList.sort(reverse= True, key= lambda a : int(a["playcount"]))

        
    def transclude(self, message: str) -> str:
        words = []


        for word in message.split():
            if(word[0] == '@'):
                word = self._transclude(word[1:])

            words.append(word)

        return " ".join(words)

    def _transclude(self, key:str) -> str:
        if(key == "lastfm"):
            return self.artistList[0]["name"] + ", " + self.artistList[1]["name"] + ", " + self.artistList[2]["name"]
        elif(key == "topArtist"):
            return self.artistList[0]["name"] + " with " + self.artistList[0]["playcount"] + " views"
        else:
            return "@" + key
