# OpenWeather.py
# Tulasi Janjanam
# hjanjana@uci.edu
# 35885208

from WebAPI import WebAPI

# zip = "92697"
# ccode = "US"
# weather_apikey = "3f36ce87f8a68a978b3411a275a60792"

class OpenWeather(WebAPI):
    zip = ""
    ccode = ""
    apikey = ""

    data = None

    def __init__(self, zipcode = "92697", ccode = "US"):
        self.zip = zipcode
        self.ccode = ccode

    def set_apikey(self, apikey: str) -> None:
        self.apikey = apikey

    def load_data(self) -> None:
        url = f"http://api.openweathermap.org/data/2.5/weather?zip={self.zip},{self.ccode}&appid={self.apikey}"
    
        r = super()._download_url(url)

        self.temperature = r["main"]["temp"]
        self.high_temperature = r["main"]["temp_max"]
        self.low_temperature = r["main"]["temp_min"]
        self.longitude = r["coord"]["lon"]
        self.latitude = r["coord"]["lat"]
        self.description = r["weather"][0]["description"]
        self.humidity = r["main"]["humidity"]
        self.sunset = r["sys"]["sunset"]
        self.sunrise = r["sys"]["sunrise"]


    def transclude(self, message: str) -> str:
        words = []


        for word in message.split():
            if(word[0] == '@'):
                word = self._transclude(word[1:])

            words.append(word)

        return " ".join(words)
    
    def _transclude(self, key:str) -> str:
        if(key == "weather"):
            return self.description
        elif(key == "tempHigh"):
            return self.high_temperature
        elif(key == "tempLow"):
            return self.low_temperature
        elif(key == "humidity"):
            return self.humidity
        else:
            return  "@" + key

        