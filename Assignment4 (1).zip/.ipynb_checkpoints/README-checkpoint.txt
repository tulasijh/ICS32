# Tulasi Janjanam
# hjanjana@uci.edu
# 35885208

This project extends the capabilities of the Distributed Social (DS) program by incorporating features that leverage external web APIs. In assignment 3, we learned how to establish communication between programs running on different computers. Now, we'll explore integrating data from external sources to enhance the functionality of our DS platform.

## Introduction
In assignment 4, we focus on incorporating data from two web APIs into our DS program. We'll connect to the OpenWeather API and the Last.FM API to enrich user experience and provide valuable information within journal entries. This README provides an overview of the program requirements, setup instructions, and details on integrating the APIs.


## Implementation Details
1. **OpenWeather Integration:**
   - Connect to OpenWeather API to retrieve weather data based on location.
   - Implement error handling for various conditions such as loss of internet connection or API unavailability.
2. **Last.FM Integration:**
   - Connect to Last.FM API to retrieve music-related data.
   - Implement transclusion for Last.FM data within journal entries.
3. **Refactoring:**
   - Refactor code to reduce redundancy and improve code structure using a base class (`WebAPI`) for API interactions.

