from pathlib import Path

def list_directory(path, recursive=False, files_only=False, search_name=None, extension=None):
    directory = Path(path)
    if not directory.exists() or not directory.is_dir():
        print("ERROR")
        return

    def condition(p):
        if files_only and p.is_dir():
            return False
        if search_name and search_name not in p.name:
            return False
        if extension and not p.suffix == f".{extension}":
            return False
        return True

    def list_contents(dir_path):
        try:
            for entry in dir_path.iterdir():
                if condition(entry):
                    print(entry)
                if recursive and entry.is_dir():
                    list_contents(entry)
        except PermissionError:
            print("ERROR")

    list_contents(directory)


def create_file(path, name):
    file_path = Path(path) / f"{name}.dsu"
    try:
        file_path.touch()
        print(f"{file_path}")
    except Exception as e:
        print("ERROR:", e)
        
def delete_file(path):
    file_path = Path(path)
    if file_path.suffix != '.dsu' or not file_path.is_file():
        print("ERROR")
        return
    try:
        file_path.unlink()
        print(f"{file_path} DELETED")
    except Exception as e:
        print("ERROR:", e)
        
def read_file(path):
    file_path = Path(path)
    if file_path.suffix != '.dsu' or not file_path.is_file():
        print("ERROR")
        return
    try:
        content = file_path.read_text()
        if not content:
            print("EMPTY")
        else:
            print(content,end='')
    except Exception as e:
        print("ERROR:", e)

def main():
    while True:
        user_input = input().strip().split()
        if not user_input:
            continue

        command = user_input[0].upper()
        path = user_input[1] if len(user_input) > 1 else None

        if command == 'Q':
            break
        elif command == 'L':
            path = user_input[1] if len(user_input) > 1 else "."
            recursive = '-r' in user_input
            files_only = '-f' in user_input
            search_option = '-s' in user_input
            extension_option = '-e' in user_input
            search_name = None
            extension = None

            if search_option:
                search_name_index = user_input.index('-s') + 1
                if search_name_index < len(user_input):
                    search_name = user_input[search_name_index]

            if extension_option:
                extension_index = user_input.index('-e') + 1
                if extension_index < len(user_input):
                    extension = user_input[extension_index]

            list_directory(path, recursive, files_only, search_name, extension)

        elif command == 'C' and path:
            name_index = user_input.index('-n') + 1 if '-n' in user_input else None
            name = user_input[name_index] if name_index and name_index < len(user_input) else None
            if name:
                create_file(path, name)
            else:
                print("ERROR")

        elif command == 'D' and path:
            delete_file(path)

        elif command == 'R' and path:
            read_file(path)
        else:
            print("ERROR")


if __name__ == "__main__":
    main()
