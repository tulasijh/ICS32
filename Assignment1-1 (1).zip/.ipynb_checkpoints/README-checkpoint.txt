File Management Tool

This interactive file management tool allows users to perform operations on files and directories. It supports commands for listing contents, creating files, deleting files, and reading file contents.

Part 1
L - List the contents of the user specified directory.
Options of the 'L' command

    -r Output directory content recursively.
    -f Output only files, excluding directories in the results.
    -s Output only files that match a given file name.
    -e Output only files that match a given file extension.


Q - Quit the program.

Part 2

C - Create a new file in the specified directory.
    -n Specify the name to be used for a new file.
D - Delete the file.
R - Read the contents of a file.