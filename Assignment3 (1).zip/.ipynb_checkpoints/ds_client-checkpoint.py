# Starter code for assignment 3 in ICS 32 Programming with Software Libraries in Python

# Replace the following placeholders with your information.

# Tulasi Janjanam
# hjanjana@uci.edu
# 35885208

import socket
import json
import time

def create_connection(server, port):
    """
    Establishes a socket connection to the specified server and port.

    Parameters:
        server (str): The server's IP address or hostname.
        port (int): The port number to connect to.

    Returns:
        socket.socket or None: A socket object if successful, otherwise None.
    """
    try:
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect((server, port))
        return client
    except Exception as e:
        print(f"Connection error: {e}")
        return None


def send_data(client, data):
    """
    Sends data over an established socket connection.

    Parameters:
        client (socket.socket): The socket object representing the connection.
        data (str): The data to be sent.

    Returns:
        bool: True if successful, False otherwise.
    """
    try:
        client.sendall(data.encode('utf-8'))
        return True
    except Exception as e:
        print(f"Sending data error: {e}")
        return False


def receive_response(client):
    """
    Receives response from the server over the socket connection.

    Parameters:
        client (socket.socket): The socket object representing the connection.

    Returns:
        str or None: The received response as a string if successful, otherwise None.
    """
    try:
        response = client.recv(1024).decode('utf-8')
        print("Server message: ", json.loads(response)["response"].get("message"))
        return response
    except Exception as e:
        print(f"Receiving data error: {e}")
        return None



def send(server: str, port: int, username: str, password: str, message: str, bio: str = None):
    '''
  The send function joins a ds server and sends a message, bio, or both

  :param server: The ip address for the ICS 32 DSP server.
  :param port: The port where the ICS 32 DSP server is accepting connections.
  :param username: The user name to be assigned to the message.
  :param password: The password associated with the username.
  :param message: The message to be sent to the server.
  :param bio: Optional, a bio for the user.
  '''
    client = create_connection(server, port)
    if not client:
        return False

    try:
        # Prepare join command and send
        join_data = json.dumps({"join": {"username": username, "password": password, "token": ""}})
        if not send_data(client, join_data):
            return False

        # Receive join response
        join_response = receive_response(client)
        if not join_response or '"type": "error"' in join_response:
            return False
        
        token = json.loads(join_response)["response"].get("token")
        

        # If a message is provided, send it
        if message:
            message_data = json.dumps({"token": token, "post": {"entry": message, "timestamp": time.time()}})
            if not send_data(client, message_data):
                return False

        # If a bio is provided, send it
        if bio:
            bio_data = json.dumps({"token": token, "bio": {"entry": bio, "timestamp": time.time()}})
            if not send_data(client, bio_data):
                return False

        client.close()
        return True
    except Exception as e:
        print(f"Error during send operation: {e}")
        return False
    finally:
        client.close()
