Assignment 3: Publishing Online
This project is an extension of a journaling program developed for Assignment 2. The goal of this assignment is to introduce an online publishing option to the program, allowing users to share their journal entries on a remote server using a custom communication protocol.

Program Overview
The program is divided into multiple modules, each serving a specific purpose:

a3.py: Entry point of the program responsible for importing and utilizing other modules.
ds_protocol.py: Implementation of the DSP (Distributed Social Platform) protocol.
ds_client.py: Module for communicating with the remote DSP server.
Profile.py: Module for storing user information.
ui.py: User interface module from Assignment 2


Part 1: Communication Protocol
Implemented functions to connect to the DSP server and send messages using sockets.
Developed error handling mechanisms to gracefully handle exceptions.
Adapted the DSP protocol for use in the program, supporting commands such as 'join', 'post', and 'bio'.

Part 2: User Interface Extension
Extended the user interface to collect the desired DSP server from the user.
Implemented functionality to allow users to post journal entries to the DSP server.
Incorporated error messages and validation to ensure data integrity and user-friendly experience.
