# ds_protocol.py

# Starter code for assignment 3 in ICS 32 Programming with Software Libraries in Python

# Replace the following placeholders with your information.

# Tulasi Janjanam
# hjanjana@uci.edu
# 35885208

import json
from collections import namedtuple

# Namedtuple for response parsing
ResponseTuple = namedtuple('ResponseTuple', ['type', 'message', 'token'])


def create_join_command(username: str, password: str) -> str:
    """
    Create a JSON string for the 'join' command.

    Parameters:
        username (str): The username for the join command.
        password (str): The password for the join command.

    Returns:
        str: JSON string representing the 'join' command.
    """
    return json.dumps({"join": {"username": username, "password": password, "token": ""}})


def create_post_command(token: str, entry: str, timestamp: str) -> str:
    """
    Create a JSON string for the 'post' command.

    Parameters:
        token (str): The authentication token.
        entry (str): The content of the post.
        timestamp (str): The timestamp of the post.

    Returns:
        str: JSON string representing the 'post' command.
    """
    return json.dumps({"token": token, "post": {"entry": entry, "timestamp": timestamp}})


def create_bio_command(token: str, entry: str, timestamp: str) -> str:
    """
    Create a JSON string for the 'bio' command.

    Parameters:
        token (str): The authentication token.
        entry (str): The content of the bio.
        timestamp (str): The timestamp of the bio.

    Returns:
        str: JSON string representing the 'bio' command.
    """
    return json.dumps({"token": token, "bio": {"entry": entry, "timestamp": timestamp}})


def extract_json(json_msg: str) -> ResponseTuple:
    """
    Extract relevant information from a JSON message and return it as a ResponseTuple object.

    Parameters:
        json_msg (str): The JSON message string.

    Returns:
        ResponseTuple or None: A ResponseTuple object containing the extracted information,
        or None if an error occurs during decoding or parsing.
    """
    try:
        json_obj = json.loads(json_msg)
        response_type = json_obj['response']['type']
        message = json_obj['response'].get('message', '')  # Use get to provide a default empty string if 'message' is missing
        token = json_obj['response'].get('token', '')  # Use get to provide a default empty string if 'token' is missing
        return ResponseTuple(response_type, message, token)
    except json.JSONDecodeError:
        print("JSON cannot be decoded.")
        return None
    except KeyError as e:
        print(f"Key error: {e}")
        return None

