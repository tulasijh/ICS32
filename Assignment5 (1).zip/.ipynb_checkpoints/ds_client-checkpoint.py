# ds_client.py
# Tulasi Janjanam
# hjanjana@uci.edu
# 35885208

import socket
import json
import time


def create_connection(server, port):
    try:
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect((server, port))
        return client
    except Exception as e:
        print(f"Connection error: {e}")
        return None


def send_data(client, data):
    try:
        client.sendall(data.encode('utf-8'))
        return True
    except Exception as e:
        print(f"Sending data error: {e}")
        return False


def receive_response(client):
    try:
        response = client.recv(1024).decode('utf-8')
        print("Server message: ",json.loads(response)["response"].get("message"))
        return response
    except Exception as e:
        print(f"Receiving data error: {e}")
        return None


def send(server: str, username: str, password: str, message: str, bio: str = None, port=3021):
    client = create_connection(server, port)
    if not client:
        return False

    try:
        # Prepare join command and send
        join_data = json.dumps({"join": {"username": username, "password": password, "token": ""}})
        if not send_data(client, join_data):
            return False

        # Receive join response
        join_response = receive_response(client)
        if not join_response or '"type": "error"' in join_response:
            return False
        
        token = json.loads(join_response)["response"].get("token")
        

        # If a message is provided, send it
        if message:
            message_data = json.dumps({"token": token, "post": {"entry": message, "timestamp": time.time()}})
            if not send_data(client, message_data):
                return False

        # If a bio is provided, send it
        if bio:
            bio_data = json.dumps({"token": token, "bio": {"entry": bio, "timestamp": time.time()}})
            if not send_data(client, bio_data):
                return False

        client.close()
        return True
    except Exception as e:
        print(f"Error during send operation: {e}")
        return False
    finally:
        client.close()
