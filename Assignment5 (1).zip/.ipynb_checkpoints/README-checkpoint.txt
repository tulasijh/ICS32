# README.txt
# Tulasi Janjanam
# hjanjana@uci.edu
# 35885208

**Direct Messaging System with Tkinter GUI**

This project implements a direct messaging system with a graphical user interface (GUI) using Python and Tkinter. The system allows users to send and receive direct messages to other users on the DSP platform. 

1. **Protocol Implementation:**
   - Extended `ds_protocol` module for direct messaging commands.
   - Implemented functions for sending, requesting unread, and requesting all messages.
   - Tested functionality in `test_ds_message_protocol.py`.

2. **Direct Messenger Module:**
   - Developed `ds_messenger.py` for messaging operations.
   - Created `DirectMessage` class for message representation.
   - Implemented `DirectMessenger` class for sending and retrieving messages.
   - Ensured module operates independently and tested in `test_ds_messenger.py`.

3. **Local Message Storage:**
   - Implemented local storage for message data.
   - Enabled program to retrieve stored messages and recipients locally.
   - Validated storage functionality with tests.

4. **Graphical User Interface (GUI):**
   - Created Tkinter-based GUI for messaging system.
   - Designed interface with widgets for messages, contacts, and input.
   - Implemented automatic message retrieval and conversation display.
   - Customized layout and design as needed.
   - Tested GUI functionality with test cases.

