# ds_messenger.py
# Tulasi Janjanam
# hjanjana@uci.edu
# 35885208

import socket
import json
import time


class DirectMessage:
    def __init__(self, recipient=None, message=None, timestamp=None):
        self.recipient = recipient
        self.message = message
        self.timestamp = timestamp

class DirectMessenger:
    def __init__(self, dsuserver = None, username = None, password = None, port =3021):
        self.token = None
        self.dsuserver = dsuserver
        self.port = port
        self.username = username
        self.password = password

    def send(self, message:str, recipient:str) -> bool:
        client = self.create_connection(self.dsuserver, self.port)

        if not client:
            return False

        try:
            # Prepare join command and send
            join_data = json.dumps({"join": {"username": self.username, "password": self.password, "token": ""}})

            if not self.send_data(client, join_data):
                return False

            # Receive join response
            join_response = self.receive_response(client)
            if not join_response or '"type": "error"' in join_response:
                return False
            
            self.token = json.loads(join_response)["response"].get("token")
            

            # If a message is provided, send it
            if message:
                message_data = json.dumps({"token": self.token, "directmessage": {"entry": message, "recipient": recipient, "timestamp": time.time()}})
                if not self.send_data(client, message_data):
                    return False
            else:
                print("No message entered.")
                return False

            client.close()
            return True
        except Exception as e:
            print(f"Error during send operation: {e}")
            return False
        finally:
            client.close()

    def retrieve_news(self) -> list:
        return self._retrieve_messages("new")
    
    def retrieve_all(self) -> list:
        return self._retrieve_messages("all")

    def _retrieve_messages(self, type="new"):

        client = self.create_connection(self.dsuserver, self.port)

        if not client:
            return None
        
        try:
            # Prepare join command and send
            join_data = json.dumps({"join": {"username": self.username, "password": self.password, "token": ""}})

            if not self.send_data(client, join_data):
                return None

            # Receive join response
            join_response = self.receive_response(client)
            if not join_response or '"type": "error"' in join_response:
                return None
            
            self.token = json.loads(join_response)["response"].get("token")

            request_data = json.dumps({"token": self.token, "directmessage": type})
            if not self.send_data(client, request_data):
                return False
            
            news_response = self.receive_response(client)
            if not news_response or '"type": "error"' in news_response:
                return None

            return self.extract_direct_message_list(news_response)
        
        except Exception as e:
            print(f"Error during send operation: {e}")
            return False
        finally:
            client.close()
    


    def extract_direct_message_list(self, json_msg: str):
        try:
            json_obj = json.loads(json_msg)
            
            message_list = []

            response_type = json_obj['response']['type']

            if response_type == "error":
                return None

            messages = json_obj['response'].get('messages', [])
            
            recipient = self.username

            for m in messages:
                entry = m['message'] 
                sender = m['from']
                time = m['timestamp']

                message_list.append(DirectMessage(self.username, entry, time))
            
            return message_list
        
        except json.JSONDecodeError:
            print("JSON cannot be decoded.")
            return None
        except KeyError as e:
            print(f"Key error: {e}")
            return None



    def create_connection(self, server, port):
        try:
            client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client.connect((server, port))
            return client
        except Exception as e:
            print(f"Connection error: {e}")
            return None
        
    def receive_response(self, client):
        try:
            response = client.recv(1024).decode('utf-8')
            # print("Server message: ",json.loads(response)["response"].get("message"))
            return response
        except Exception as e:
            print(f"Receiving data error: {e}")
            return None


    
    def send_data(self, client, data):
        try:
            client.sendall(data.encode('utf-8'))
            return True
        except Exception as e:
            print(f"Sending data error: {e}")
            return False
