# test_ds_message_protocol.py
# Tulasi Janjanam
# hjanjana@uci.edu
# 35885208

import ds_protocol as ds
import time

print(ds.create_direct_message("token", "Hello world", "mark", time.time()))

print(ds.extract_direct_message_list('{"response" : {"type" : "ok", "messages" : [{"message" : "Hello User 1!", "recipient": "markb", "timestamp" : "1603167689.3924"}, {"message" : "Bzzzz", "recipient": "thebeemoviescript", "timestamp" : "1603167689.3924"}]}}'))