# ds_protocal.py
# Tulasi Janjanam
# hjanjana@uci.edu
# 35885208

import json
from collections import namedtuple

# Namedtuple for response parsing
ResponseTuple = namedtuple('ResponseTuple', ['type', 'message', 'token'])
DirectMessage = namedtuple('DirectMessage', ['message', 'recipient', 'timestamp'])


def create_direct_message(token: str, entry: str, recipient: str, timestamp: str):
    return json.dumps({"token": token, "directmessage": {"entry": entry, "recipient": recipient, "timestamp": timestamp}})


def extract_direct_message_list(json_msg: str):
    try:
        json_obj = json.loads(json_msg)
        
        message_list = []

        response_type = json_obj['response']['type']

        messages = json_obj['response'].get('messages', [])

        for m in messages:
            entry = m['message']
            sender = m['recipient']
            time = m['timestamp']

            message_list.append(DirectMessage(entry, sender, time))
        
        return message_list
    
    except json.JSONDecodeError:
        print("JSON cannot be decoded.")
        return None
    except KeyError as e:
        print(f"Key error: {e}")
        return None



def create_join_command(username: str, password: str):
    return json.dumps({"join": {"username": username, "password": password, "token": ""}})


def create_post_command(token: str, entry: str, timestamp: str):
    return json.dumps({"token": token, "post": {"entry": entry, "timestamp": timestamp}})


def create_bio_command(token: str, entry: str, timestamp: str):
    return json.dumps({"token": token, "bio": {"entry": entry, "timestamp": timestamp}})


def extract_json(json_msg: str) -> ResponseTuple:
    '''
    Call the json.loads function on a json string and convert it to a ResponseTuple object
    '''
    try:
        json_obj = json.loads(json_msg)
        response_type = json_obj['response']['type']
        message = json_obj['response'].get('message', '')  # Use get to provide a default empty string if 'message' is missing
        token = json_obj['response'].get('token', '')  # Use get to provide a default empty string if 'token' is missing
        return ResponseTuple(response_type, message, token)
    except json.JSONDecodeError:
        print("JSON cannot be decoded.")
        return None
    except KeyError as e:
        print(f"Key error: {e}")
        return None

