# test_ds_messenger.py
# Tulasi Janjanam
# hjanjana@uci.edu
# 35885208

from ds_messenger import DirectMessenger, DirectMessage

def test_send_message(sender: DirectMessenger, recipient: DirectMessenger, message="testing send message"):
    success = sender.send(message, recipient.username)

    if success:
        print("Successfully sent message to", recipient.username)
    else:
        print("Fialed to send message to", recipient.username)

def test_recieve_new_message(recipient: DirectMessenger):
    messages = recipient.retrieve_news()

    print("New messages for", recipient.username)

    if(messages):
        print("New messages: ")

        for message in messages:
            print()
            print("To:", message.recipient)
            print(message.message)
            print("Sent at:", message.timestamp)
            print()

    else:
        print("No new messages retrieved")

def test_recieve_all_message(recipient: DirectMessenger):
    messages = recipient.retrieve_all()

    print("All messages for", recipient.username)

    if(messages):
        print("All messages: ")

        for message in messages:
            print()
            print("To:", message.recipient)
            print(message.message)
            print("Sent at:", message.timestamp)
            print()

    else:
        print("No messages retrieved")

messenger1 = DirectMessenger(dsuserver="168.235.86.101", username="messenger1", password="password", port= 3021)
messenger2 = DirectMessenger(dsuserver="168.235.86.101", username="messenger2", password="password", port= 3021)

# test_send_message(messenger1, messenger2)
# test_send_message(messenger1, messenger2, "test 2")

# test_send_message(messenger2, messenger1)
# test_send_message(messenger1, messenger2, "testing 2")

# test_recieve_new_message(messenger1)
# test_recieve_new_message(messenger2)

# test_send_message(messenger1, messenger2, "test 3")
# test_send_message(messenger1, messenger2, "test 4")

# test_recieve_new_message(messenger1)
# test_recieve_new_message(messenger2)


# test_send_message(messenger1, messenger2, "test 5")
# test_send_message(messenger1, messenger2, "test 6")

# test_send_message(messenger2, messenger1, "test 7")
# test_send_message(messenger2, messenger1, "testing 8")

# test_recieve_all_message(messenger1)
# test_recieve_all_message(messenger2)