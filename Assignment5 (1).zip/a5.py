# a5.py
# Tulasi Janjanam
# hjanjana@uci.edu
# 35885208

import tkinter as tk
from tkinter import ttk, filedialog, simpledialog, messagebox
from typing import Text
from ds_messenger import DirectMessage, DirectMessenger
import ds_client
import time
from Profile import Profile
from pathlib import Path
import json

class Body(tk.Frame):
    def __init__(self, root, recipient_selected_callback=None):
        tk.Frame.__init__(self, root)
        self.root = root
        self._contacts = [str]
        self._select_callback = recipient_selected_callback
        self._draw()

    def node_select(self, event):
        index = int(self.posts_tree.selection()[0])
        entry = self._contacts[index]
        if self._select_callback is not None:
            self._select_callback(entry)

    def clear_contacts(self):
        for contact in self.posts_tree.get_children():
            self.posts_tree.delete(contact)

        self.posts_tree.selection_clear()

    def insert_contact(self, contact: str):
        if contact is None:
            return
        
        self._contacts.append(contact)
        id = len(self._contacts) - 1
        self._insert_contact_tree(id, contact)

    def _insert_contact_tree(self, id, contact: str):
        if contact is None:
            return
        
        if len(contact) > 25:
            entry = contact[:24] + "..."
        id = self.posts_tree.insert('', id, id, text=contact)

    def insert_user_message(self, message:str):
        self.entry_editor.insert(1.0, message + '\n\n', 'entry-right')

    def insert_contact_message(self, message:str):
        self.entry_editor.insert(1.0, message + '\n\n', 'entry-left')

    def clear_contact_message(self):
        self.entry_editor.delete(1.0, tk.END)



    def get_text_entry(self) -> str:
        return self.message_editor.get('1.0', 'end').rstrip()



    def set_text_entry(self, text:str):
        self.message_editor.delete(1.0, tk.END)
        self.message_editor.insert(1.0, text)

    def _draw(self):
        posts_frame = tk.Frame(master=self, width=250)
        posts_frame.pack(fill=tk.BOTH, side=tk.LEFT)

        self.posts_tree = ttk.Treeview(posts_frame)
        self.posts_tree.bind("<<TreeviewSelect>>", self.node_select)
        self.posts_tree.pack(fill=tk.BOTH, side=tk.TOP,
                             expand=True, padx=5, pady=5)

        entry_frame = tk.Frame(master=self, bg="")
        entry_frame.pack(fill=tk.BOTH, side=tk.TOP, expand=True)

        editor_frame = tk.Frame(master=entry_frame, bg="red")
        editor_frame.pack(fill=tk.BOTH, side=tk.LEFT, expand=True)

        scroll_frame = tk.Frame(master=entry_frame, bg="blue", width=10)
        scroll_frame.pack(fill=tk.BOTH, side=tk.LEFT, expand=False)

        message_frame = tk.Frame(master=self, bg="yellow")
        message_frame.pack(fill=tk.BOTH, side=tk.TOP, expand=False)

        self.message_editor = tk.Text(message_frame, width=0, height=5)
        self.message_editor.pack(fill=tk.BOTH, side=tk.LEFT,
                                 expand=True, padx=0, pady=0)

        self.entry_editor = tk.Text(editor_frame, width=0, height=5)
        self.entry_editor.tag_configure('entry-right', justify='right')
        self.entry_editor.tag_configure('entry-left', justify='left')
        self.entry_editor.pack(fill=tk.BOTH, side=tk.LEFT,
                               expand=True, padx=0, pady=0)

        entry_editor_scrollbar = tk.Scrollbar(master=scroll_frame,
                                              command=self.entry_editor.yview)
        self.entry_editor['yscrollcommand'] = entry_editor_scrollbar.set
        entry_editor_scrollbar.pack(fill=tk.Y, side=tk.LEFT,
                                    expand=False, padx=0, pady=0)
        


class Footer(tk.Frame):
    def __init__(self, root, send_callback=None):
        tk.Frame.__init__(self, root)
        self.root = root
        self._send_callback = send_callback
        self._draw()

    def send_click(self):
        if self._send_callback is not None:
            self._send_callback()

    def _draw(self):
        save_button = tk.Button(master=self, text="Send", width=20, command = self.send_click)
        # You must implement this.   # OK
        # Here you must configure the button to bind its click to
        # the send_click() function.

        save_button.pack(fill=tk.BOTH, side=tk.RIGHT, padx=5, pady=5)

        self.footer_label = tk.Label(master=self, text="Ready.")
        self.footer_label.pack(fill=tk.BOTH, side=tk.LEFT, padx=5)


class NewContactDialog(tk.simpledialog.Dialog):
    def __init__(self, root, title=None, user=None, pwd=None, server=None):
        self.root = root
        self.server = server
        self.user = user
        self.pwd = pwd
        super().__init__(root, title)

    def body(self, frame):
        self.server_label = tk.Label(frame, width=30, text="DS Server Address")
        self.server_label.pack()
        self.server_entry = tk.Entry(frame, width=30)
        self.server_entry.insert(tk.END, str(self.server))
        self.server_entry.pack()

        self.username_label = tk.Label(frame, width=30, text="Username")
        self.username_label.pack()
        self.username_entry = tk.Entry(frame, width=30)
        self.username_entry.insert(tk.END, str(self.user))
        self.username_entry.pack()

        self.password_label = tk.Label(frame, width=30, text="Password")
        self.password_label.pack()
        self.password_entry = tk.Entry(frame, width=30)
        self.password_entry.insert(tk.END, str(self.pwd))
        self.password_entry['show'] = '*'
        self.password_entry.pack()


    def apply(self):
        self.user = self.username_entry.get()
        self.pwd = self.password_entry.get()
        self.server = self.server_entry.get()


class MainApp(tk.Frame):
    def __init__(self, root):
        tk.Frame.__init__(self, root)
        self.root = root
        self.username = ""
        self.password = ""
        self.server = ""
        self.bio = ""
        self.posts = []
        self.sent_messages = []
        self.recieved_messages = []
        self.contacts = []
        
        self.recipient = None

        self.direct_messenger = None

        self.path = ""


        self._draw()
        self.check_new()
        
        # self.root.after(1000, self.check_new)

    def send_message(self):
        message = self.body.get_text_entry()

        if not message:
            return

        recipient = self.recipient

        if recipient is None:
            self.raiseError("Please add/select a contact before sending a message.", title="No Recipient.")
            return

        if self.direct_messenger is None:
            self.raiseError("Please configure/load settings before sending a message.", title="Improper setup.")
            return
        

        self.direct_messenger.send(message, recipient)


        msg = message + '\n' + self.now_time(time.time())
        self.body.insert_user_message(msg)

        
        self.body.set_text_entry("")

        self.sent_messages.append(DirectMessage(recipient=self.recipient, message=message, timestamp=time.time()))

        self.save_configuration()

    def check_new(self):
        if self.direct_messenger is not None:
            messages = self.direct_messenger.retrieve_news()
        

            if(messages is None):
                messages = []

            for msg in messages:
                entry = msg.message + '\n' + self.now_time(float(msg.timestamp))
                self.body.insert_contact_message(entry)


                self.recieved_messages.append(DirectMessage(recipient=self.recipient, message=msg.message, timestamp=msg.timestamp))
        
                self.save_configuration()

        
        self.root.after(1000, self.check_new)

    def now_time(self, epochTime):
        return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(epochTime))


    def add_contact(self):
        newContact = simpledialog.askstring("New Contact", "Please enter the username:")
        
        self.body.insert_contact(newContact)

        self.contacts.append(newContact)

        self.save_configuration()

    def recipient_selected(self, recipient):
        if(self.recipient == recipient):
            return
        
        self.recipient = recipient
        self.body.clear_contact_message()
        self.load_all_messages(self.recipient)

    def load_all_messages(self, contact):
        msg_list = []

        for msg in self.sent_messages:
            sender = msg.recipient

            if sender == contact:
                msg_list.append(msg)

        for msg in self.recieved_messages:
            sender = msg.recipient

            if sender == contact:
                new_msg = DirectMessage(recipient=self.username, message=msg.message, timestamp=msg.timestamp)

                msg_list.append(new_msg)


        msg_list.sort(key=lambda msg: float(msg.timestamp))

        for msg in msg_list:
            if msg.recipient == self.username:
                entry = msg.message + '\n' + self.now_time(float(msg.timestamp))
                self.body.insert_contact_message(entry)

            else:
                msg = msg.message + '\n' + self.now_time(float(msg.timestamp))
                self.body.insert_user_message(msg)


    def configure_server(self):
        ud = NewContactDialog(self.root, "Configure Account", self.username, self.password, self.server)
        
        if ud.user == "" or ud.pwd == "" or ud.server == "":
            return
        
        self.username = ud.user
        self.password = ud.pwd
        self.server = ud.server
        self.bio = ""
        self.posts = []
        self.sent_messages = []
        self.recieved_messages = []
        self.contacts = []
        
        self.direct_messenger = DirectMessenger(dsuserver=ud.server, username = ud.user, password=ud.pwd)


        self.path = filedialog.asksaveasfilename(title="Select where to store your information", defaultextension=".dsu", filetypes=[("DSU Profile", ".dsu")])

        self.body.clear_contacts()
        self.body.clear_contact_message()
        self.save_configuration()

    def load_configuration(self):
        self.path = filedialog.askopenfilename(filetypes=[("DSU Profile", ".dsu")])
        
        if self.path  == "":
            return


        file_path = Path(self.path)
        
        if file_path.suffix == '.dsu':
            try:
                with open(file_path, "r") as file:
                    print(f"{file_path} Sucessfuly opened.")
                    profile = Profile()
                    profile.load_profile(file_path)


                    self.username = profile.username
                    self.password = profile.password
                    self.server = profile.dsuserver
                    self.sent_messages = profile.get_my_messages()
                    self.recieved_messages = profile.get_messages()

                    self.contacts = profile.contacts
                    
                    self.body.clear_contacts()
                    self.body.clear_contact_message()
                    for contact in profile.contacts:
                        self.body.insert_contact(contact)

                    self.direct_messenger = DirectMessenger(dsuserver=self.server, username = self.username, password=self.password)


            except FileNotFoundError as e:
                self.raiseError("There is no file with this name. Please try again.")
                return
        else:
            self.raiseError("Sorry, invalid file format. Please only enter a file ending in .dsu")
            return
        
    def save_configuration(self):
        x = {"username": self.username, 
             "password": self.password,
             "dsuserver": self.server,
             "bio": self.bio, 
             "_posts": self.posts,
             "_my_messages": self.message_to_json(self.sent_messages),
             "_messages": self.message_to_json(self.recieved_messages),
             "contacts": self.contacts
            }
                
        y = json.dumps(x)
        
        try:
            with open(self.path, "w") as file:
                file.write(y)
        except Exception as e:
            self.raiseError(e, "ERROR:")

    def message_to_json(self, dm_list: list[DirectMessage]):
        msg_list = []

        for dm in dm_list:
            msg = {
                "message": dm.message,
                "from": dm.recipient,
                "timestamp": dm.timestamp
            }

            msg_list.append(msg)

        return msg_list

    def json_to_message(self, dm_list: str) -> list:

        msg_list = []

        for dm in dm_list:
            msg = json.loads(dm_list)
            msg_list.append(DirectMessage(recipient=msg["from"], message=msg["message"], timestamp=msg["timestamp"]))

        return msg_list



    def raiseError(self, message:str, title="Error."):
        messagebox.showinfo(title,  message)
        return


    def publish(self, message:str):
        ds_client.send(self.server, self.username, self.password, message)

    def _draw(self):
        # Build a menu and add it to the root frame.
        menu_bar = tk.Menu(self.root)
        self.root['menu'] = menu_bar
        menu_file = tk.Menu(menu_bar)

        menu_bar.add_cascade(menu=menu_file, label='File')
        menu_file.add_command(label='New',
                                  command=self.configure_server)
        menu_file.add_command(label='Open...',
                                  command=self.load_configuration)
        menu_file.add_command(label='Close',
                                  command=quit)

        settings_file = tk.Menu(menu_bar)
        menu_bar.add_cascade(menu=settings_file, label='Settings')
        settings_file.add_command(label='Add Contact',
                                  command=self.add_contact)
        settings_file.add_command(label='Configure DS Server',
                                  command=self.configure_server)

        self.body = Body(self.root,
                         recipient_selected_callback=self.recipient_selected)
        self.body.pack(fill=tk.BOTH, side=tk.TOP, expand=True)

        self.footer = Footer(self.root, send_callback=self.send_message)
        self.footer.pack(fill=tk.BOTH, side=tk.BOTTOM)



if __name__ == "__main__":
    
    main = tk.Tk()


    main.title("ICS 32 Distributed Social Messenger")


    main.geometry("720x480")


    main.option_add('*tearOff', False)


    app = MainApp(main)



    main.update()
    main.minsize(main.winfo_width(), main.winfo_height())
    # id = main.after(1000, app.check_new)
    # print(id)


    main.mainloop()
